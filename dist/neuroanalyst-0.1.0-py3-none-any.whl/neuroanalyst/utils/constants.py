"""
NeuroAnalyst Constants Module

This module defines all the constants and environment variables used throughout
the NeuroAnalyst framework. These constants are primarily derived from environment
variables set by the setup.sh and set_envs.sh scripts.

The environment variables define the directory structure and paths for:
- Singularity/Apptainer images (base and process images)
- Working directories for temporary files
- Report outputs
- Logs
- BIDS datasets
- Documentation
"""

import os
from pathlib import Path
from typing import Optional, Literal


class NeuroAnalystPaths:
    """
    Central configuration class for all NeuroAnalyst paths and directories.
    
    This class reads environment variables set by the setup process and provides
    easy access to all important directories used by the framework.
    """
    username: Optional[str] = None
    
    def __init__(self, username: Optional[str] = None):
        # Base home directory for NeuroAnalyst
        self._home = os.getenv('NEUROANALYST_HOME', os.path.expanduser('~/neuroanalyst'))
        if username:
            self._home = os.path.join(self._home, username)
        
        #! Core directories - commented out to only use NEUROANALYST_HOME.
        #! The plan is to build user-specific paths under the home directory.
        #! The MongoDB settings will be project-wide.
        # self._images = os.getenv('NEUROANALYST_IMAGES', 
        #                         os.path.join(self._home, 'apptainer', 'images'))
        # self._docs = os.getenv('NEUROANALYST_DOCS', 
        #                       os.path.join(self._home, 'apptainer', 'docs'))
        # self._workdir = os.getenv('NEUROANALYST_WORKDIR', 
        #                          os.path.join(self._home, 'working_dirs'))
        # self._pipelines = os.getenv('NEUROANALYST_PIPELINES',
        #                            os.path.join(self._home, 'pipelines'))
        # self._reports = os.getenv('NEUROANALYST_REPORTS', 
        #                          os.path.join(self._home, 'reports'))
        # self._logs = os.getenv('NEUROANALYST_LOGS', 
        #                       os.path.join(self._home, 'logs'))
        # self._datasets = os.getenv('NEUROANALYST_DATASETS', 
        #                           os.path.join(self._home, 'datasets'))
        # self._venvs = os.getenv('NEUROANALYST_VENVS', 
        #                        os.path.join(self._home, 'virtual_environments'))
        # self._process_execs = os.getenv('NEUROANALYST_PROCESS_EXECS',
        #                               os.path.join(self._home, 'process_execs'))
        # self._config = os.getenv('NEUROANALYST_CONFIG',
        #                         os.path.join(self._home, 'config'))
        # self._functions = os.getenv('NEUROANALYST_FUNCTIONS',
        #                            os.path.join(self._home, 'functions'))
        
        # # MongoDB configuration
        # self._db_host = os.getenv('NEUROANALYST_DB_HOST', 'localhost')
        # self._db_port = int(os.getenv('NEUROANALYST_DB_PORT', '27017'))
        # self._db_name = os.getenv('NEUROANALYST_DB_NAME', 'neuroanalyst')
        
        # Only use the NEURONALYST_HOME env variable for now
        self._images = os.path.join(self._home, 'apptainer', 'images')
        self._docs = os.path.join(self._home, 'apptainer', 'docs')
        self._workdir = os.path.join(self._home, 'working_dirs')
        self._pipelines = os.path.join(self._home, 'pipelines')
        self._reports = os.path.join(self._home, 'reports')
        self._logs = os.path.join(self._home, 'logs')
        self._datasets = os.path.join(self._home, 'datasets')
        self._venvs = os.path.join(self._home, 'virtual_environments')
        self._process_execs = os.path.join(self._home, 'process_execs')
        self._config = os.path.join(self._home, 'config')
        self._functions = os.path.join(self._home, 'functions')
        self._recipes = os.path.join(self._home, 'recipes')
        
        # MongoDB configuration
        self._db_host = 'localhost'
        self._db_port = 27017
        self._db_name = 'neuroanalyst'

    @property
    def home(self) -> Path:
        """Base NeuroAnalyst home directory."""
        return Path(self._home)
    
    @property
    def images(self) -> Path:
        """Directory for Singularity/Apptainer images (base and process images)."""
        dir_path: Path = Path(self._images)
        dir_path.mkdir(parents=True, exist_ok=True)
        return Path(self._images)
    
    @property
    def base_images(self) -> Path:
        """Directory for base Singularity images."""
        dir_path: Path = self.images / 'base'
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path
    
    @property
    def process_images(self) -> Path:
        """Directory for process Singularity images."""
        dir_path: Path = self.images / 'processes'
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path
    
    @property
    def docs(self) -> Path:
        """Directory for Apptainer/Singularity documentation and def files."""
        dir_path: Path = Path(self._docs)
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path

    @property
    def workdir(self) -> Path:
        """Working directory containing NeuProcessDir files."""
        dir_path: Path = Path(self._workdir)
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path

    @property
    def pipelines(self) -> Path:
        """Directory for storing pipeline scripts and related files."""
        dir_path: Path = Path(self._pipelines)
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path

    @property
    def reports(self) -> Path:
        """Directory for generated reports and outputs."""
        dir_path: Path = Path(self._reports)
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path
    
    @property
    def logs(self) -> Path:
        """Directory for log files."""
        dir_path: Path = Path(self._logs)
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path
    
    @property
    def datasets(self) -> Path:
        """Directory for BIDS datasets."""
        dir_path: Path = Path(self._datasets)
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path
    
    @property
    def venvs(self) -> Path:
        """Directory for virtual environments."""
        dir_path: Path = Path(self._venvs)
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path
    
    @property
    def process_execs(self) -> Path:
        """Directory for process execution instances."""
        dir_path: Path = Path(self._process_execs)
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path

    @property
    def config(self) -> Path:
        """Directory for configuration files."""
        dir_path: Path = Path(self._config)
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path

    @property
    def functions(self) -> Path:
        """Directory for function files."""
        dir_path: Path = Path(self._functions)
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path

    @property
    def db_host(self) -> str:
        """MongoDB host."""
        return self._db_host
    
    @property
    def db_port(self) -> int:
        """MongoDB port."""
        return self._db_port
    
    @property
    def db_name(self) -> str:
        """MongoDB database name."""
        return self._db_name
    
    @property
    def recipes(self) -> Path:
        """Directory for recipe files."""
        dir_path: Path = Path(self._recipes)
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path
    
    def create_directories(self) -> None:
        """
        Create all necessary directories if they don't exist.
        
        This method ensures that all the required directory structure
        is in place for NeuroAnalyst to function properly.
        """
        directories = [
            self.home,
            self.images,
            self.base_images,
            self.process_images,
            self.docs,
            self.workdir,
            self.reports,
            self.logs,
            self.datasets,
            self.venvs,
            self.process_execs,
            self.config,
            self.functions,
            self.recipes
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
    
    def get_process_workdir(self, process_id: str) -> Path:
        """
        Get a working directory for a specific NeuProcess.
        
        Args:
            process_id: Unique identifier for the process
            
        Returns:
            Path to the process-specific working directory
        """
        return self.workdir / process_id
    
    def get_pipeline_workdir(self, pipeline_id: str) -> Path:
        """
        Get a working directory for a specific NeuPipeline.
        
        Args:
            pipeline_id: Unique identifier for the pipeline
            
        Returns:
            Path to the pipeline-specific working directory
        """
        return self.workdir / 'pipelines' / pipeline_id
    
    def get_process_image_path(self, process_name: str, version: Optional[str] = None) -> Path:
        """
        Get the path for a NeuProcess image.
        
        Args:
            process_name: Name of the process
            version: Version of the process (optional)
            
        Returns:
            Path to the process image file
        """
        if version:
            filename = f"{process_name}_v{version}.sif"
        else:
            filename = f"{process_name}.sif"
        return self.process_images / filename
    
    def get_base_image_path(self, base_image_name: str) -> Path:
        """
        Get the path for a base image.
        
        Args:
            base_image_name: Name of the base image
            
        Returns:
            Path to the base image file
        """
        return self.base_images / f"{base_image_name}.sif"
    
    def get_venv_path(self, process_id: str) -> Path:
        """
        Get the path for a process execution virtual environment.
        
        Args:
            process_id: Unique identifier for the process
            
        Returns:
            Path to the virtual environment directory
        """
        return self.venvs / process_id
    
    def get_process_exec_path(self, exec_id: str) -> Path:
        """
        Get the path for a process execution instance.
        
        Args:
            exec_id: Unique identifier for the execution instance
            
        Returns:
            Path to the process execution directory
        """
        return self.process_execs / exec_id
    
    def get_log_file_path(self, component: str, id: str) -> Path:
        """
        Get the path for a log file of a specific component.
        
        Args:
            component: Component name (e.g., 'process', 'pipeline')
            id: Unique identifier for the component
        Returns:
            Path to the log file
        """
        return self.logs / component / id / f"{id}.log"
    
    def get_function_workdir(self, function_name: str) -> Path:
        """
        Get a working directory for a specific function.
        
        Args:
            function_name: Name of the function

        Returns:
            Path to the function's working directory
        """
        return self.functions / function_name
    
    def get_recipes_dir(self, component: Literal["process", "logic", "pipeline", None]) -> Path:
        """
        Get the directory for recipe files. Optionally specify a component subdirectory.
        
        Returns:
            Path to the recipes directory
        """
        dir_path: Path = self.recipes / (component if component else "")
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path


# Global instance for easy access throughout the framework
PATHS = NeuroAnalystPaths()


# Additional constants for the framework
class NeuroAnalystConfig:
    """Configuration constants for NeuroAnalyst framework."""
    
    # Singularity/Apptainer constants
    SINGULARITY_EXTENSION = '.sif'
    DEFINITION_EXTENSION = '.def'
    
    # File extensions
    PYTHON_EXTENSION = '.py'
    SHELL_EXTENSION = '.sh'
    JSON_EXTENSION = '.json'
    
    # Template file names - Simplified naming
    MAIN_TEMPLATE = 'main.py.template'
    MAIN_BULK_TEMPLATE = 'main_bulk.py.template'
    README_TEMPLATE = 'readme.md.template'
    INSTALL_TEMPLATE = 'install.sh.template'
    CONTAINER_TEMPLATE = 'container.def.template'
    EXECUTE_TEMPLATE = 'execute.sh.template'
    
    # Default file names for NeuProcess
    MAIN_SCRIPT_NAME = 'main.py'
    INSTALL_SCRIPT_NAME = 'install_requirements.sh'
    EXECUTE_SCRIPT_NAME = 'execute.sh'
    README_NAME = 'README.md'
    CONFIG_NAME = 'neuprocess_config.json'
    MODEL_DUMP_NAME = 'neuprocess_dir_model.json'
    
    # BIDS constants
    DERIVATIVES_DIR = 'derivatives'
    BIDS_SIDECAR_SUFFIX = '.json'
    
    # Processing constants
    DEFAULT_PYTHON_VERSION = '3.12'
    DEFAULT_BASE_IMAGE = 'ubuntu:22.04'
    
    # Security and permissions
    BIDS_MOUNT_MODE = 'ro'  # Read-only mount for BIDS datasets
    DERIVATIVES_MOUNT_MODE = 'rw'  # Read-write mount for derivatives
    
    # Parallel processing
    DEFAULT_N_PROCS = 4
    
    # Logging
    LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    LOG_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'
    
    # Custom BIDS config file name
    CUSTOM_BIDS_CONFIG_PATH = 'bids_with_desc.json'


# Global config instance
CONFIG = NeuroAnalystConfig()


# def ensure_directories() -> None:
#     """
#     Ensure all required NeuroAnalyst directories exist.
    
#     This function should be called during initialization to ensure
#     the directory structure is properly set up.
#     """
#     PATHS.create_directories()
    


def get_template_path(template_name: str) -> Path:
    """
    Get the path to a template file.
    
    Args:
        template_name: Name of the template file
        
    Returns:
        Path to the template file
    """
    # Assuming templates are in the app/models/process/templates directory
    base_path = Path(__file__).parent.parent / 'models' / 'process' / 'templates'
    return base_path / template_name


def validate_environment() -> bool:
    """
    Validate that all required environment variables are set.
    
    Returns:
        True if all required environment variables are set, False otherwise
    """
    required_vars = [
        'NEUROANALYST_HOME',
        # 'NEUROANALYST_DOCS',
        # 'NEUROANALYST_IMAGES',
        # 'NEUROANALYST_WORKDIR',
        # 'NEUROANALYST_PIPELINES',
        # 'NEUROANALYST_REPORTS',
        # 'NEUROANALYST_LOGS',
        # 'NEUROANALYST_DATASETS',
        # 'NEUROANALYST_VENVS',
        # 'NEUROANALYST_PROCESS_EXECS',
        # 'NEUROANALYST_CONFIG',
        # 'NEUROANALYST_FUNCTIONS',
        # 'NEUROANALYST_DB_HOST',
        # 'NEUROANALYST_DB_PORT',
        # 'NEUROANALYST_DB_NAME'
    ]
    
    missing_vars = []
    for var in required_vars:
        if not os.getenv(var):
            missing_vars.append(var)
    
    if missing_vars:
        print(f"Warning: Missing environment variables: {', '.join(missing_vars)}")
        print("Please run setup.sh to configure the environment properly.")
        return False
    
    return True

# Validate environment on import
if not validate_environment():
    print("Environment validation failed. Some features may not work correctly.")
