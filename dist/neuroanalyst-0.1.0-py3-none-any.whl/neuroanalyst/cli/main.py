"""
Comprehensive interactive CLI app for NeuroAnalyst.

CRUD and monitor operations for Logics, Processes, and Pipelines

User Experience-
- One command to launch the CLI app: `neuroanalyst-cli`
- Interactive prompts for user inputs
- Clear display of information and options
- Error handling and validation for user inputs

Visual Components-
- Expandable columns for detailed views
- Left column: "Logic", "Process", "Pipeline" views

Logic
- Expands to "Create" and "View
- Create: Loads the logic recipe wizard
- View: Lists existing logics with details
    - Upon selection, POPUP displays full logic details with options to Delete or Edit

Process
- Expands to "Create" and "View"
- Create: Loads the process recipe wizard
- View: Lists existing processes with details
    - Upon selection, POPUP displays full process details with options to Delete or Edit

Pipeline
- Expands to "Create" and "View"
- Create: Loads the pipeline recipe wizard
- View: Lists existing pipelines with details
    - Upon selection, POPUP displays full pipeline details
        - Collapsible tables to represent steps with each row representing a process exec
        - Each row has options to kill if running, and view logs
        - View logs opens a POPUP with log content - .err and .log files on two tabs
        - Options to Delete the pipeline
"""

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[2]))

from neuroanalyst.models.process.logic.core import NeuProcessLogic
from neuroanalyst.models.process.dir.core import NeuProcessDir  
from neuroanalyst.models.process.process.core import NeuProcess
from neuroanalyst.models.process.exec.core import NeuProcessExec, HPCScheduler, ExecutionMode
from neuroanalyst.models.pipeline.core import NeuPipeline, NeuPipelineStep, NeuPipelineStatus
from neuroanalyst.models.recipe.core import (
    LogicRecipe,
    ProcessDirRecipe, 
    PipelineRecipe,
    PipelineStepRecipe,
    ProcessExecInStepRecipe,
    create_logic_from_recipe,
    create_process_dir_from_recipe,
    construct_pipeline_from_recipe,
    save_recipe_to_yaml
)
from neuroanalyst.utils.constants import NeuroAnalystPaths
from neuroanalyst.models.about import About

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.columns import Columns
from rich.text import Text
from rich.tree import Tree
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt, Confirm, IntPrompt
from rich.live import Live
from rich.layout import Layout
from pydantic import BaseModel, ValidationError
from typing import Optional, List, Dict, Any, Union, get_args, get_origin
import json
import os
from datetime import datetime

console = Console()
app = typer.Typer(name="neuroanalyst-cli")

class NeuroAnalystCLI:
    """Main CLI application class for NeuroAnalyst"""
    
    def __init__(self):
        self.paths = NeuroAnalystPaths()
        self.current_username = None
        
    def get_username(self) -> str:
        """Get or prompt for username"""
        if self.current_username is None:
            default_user = None
            self.current_username = Prompt.ask(
                "Enter username", 
                default=default_user
            )
        return self.current_username

    def interactive_select(self, items: list[str], title: str = "Select an option", allow_cancel: bool = True) -> Optional[str]:
        """Interactive selection from a list of items"""
        if not items:
            return None
            
        choices = items.copy()
        if allow_cancel:
            choices.append("Cancel")
            
        console.print(f"\n[bold]{title}:[/bold]")
        for i, choice in enumerate(choices):
            console.print(f"{i+1}. {choice}")
            
        while True:
            try:
                selection = IntPrompt.ask(
                    f"Enter choice (1-{len(choices)})",
                    default=1
                )
                if 1 <= selection <= len(choices):
                    selected = choices[selection - 1]
                    if selected == "Cancel":
                        return None
                    return selected
                else:
                    console.print(f"[red]Please enter a number between 1 and {len(choices)}[/red]")
            except KeyboardInterrupt:
                return None

    def main_menu(self):
        """Main application menu"""
        console.rule("[bold blue]NeuroAnalyst CLI")
        console.print("Welcome to the comprehensive NeuroAnalyst CLI interface!")
        console.print()
        
        while True:
            choice = self.interactive_select(
                ["Logic", "Process", "Pipeline", "Exit"],
                "Select component to manage"
            )
            
            if choice == "Logic":
                self.logic_menu()
            elif choice == "Process":
                self.process_menu()
            elif choice == "Pipeline":
                self.pipeline_menu()
            elif choice == "Exit":
                console.print("[green]Goodbye![/green]")
                break
            else:
                break

    def logic_menu(self):
        """Logic management menu"""
        while True:
            choice = self.interactive_select(
                ["Create new Logic", "View existing Logics", "Back to main menu"],
                "Logic operations"
            )
            
            if choice == "Create new Logic":
                self.create_logic()
            elif choice == "View existing Logics":
                self.view_logics()
            else:
                break

    def create_logic(self):
        """Interactive logic creation using recipe pattern"""
        console.rule("[bold green]Create New Logic")
        
        try:
            # Get basic logic info
            name = Prompt.ask("Logic name")
            description = Prompt.ask("Description (optional)", default="")
            
            # Get language
            language = self.interactive_select(
                ["python", "bash", "other"],
                "Select language"
            )
            if not language:
                return
            
            # Get processing level
            level = self.interactive_select(
                ["file", "bulk"],
                "Select processing level"
            )
            if not level:
                return
            
            # Get function code
            code_option = self.interactive_select(
                ["Enter code directly", "Provide path to file"],
                "Function code options"
            )
            if not code_option:
                return
            
            if code_option == "Enter code directly":
                console.print("\nEnter your function code (press Enter twice to finish):")
                lines = []
                while True:
                    line = input()
                    if line.strip() == "" and len(lines) > 0 and lines[-1].strip() == "":
                        break
                    lines.append(line)
                function_string = '\n'.join(lines[:-1])  # Remove the last empty line
            else:
                file_path = Prompt.ask("Enter path to code file")
                try:
                    if not Path(file_path).exists():
                        console.print(f"[red]File not found: {file_path}[/red]")
                        return
                    function_string = file_path  # Recipe will handle file reading
                except Exception as e:
                    console.print(f"[red]Error accessing file: {e}[/red]")
                    return
            
            # Create recipe
            recipe = LogicRecipe(
                path=function_string if code_option == "Provide path to file" else "direct_input",
                function=function_string if code_option == "Enter code directly" else None,
                username=self.get_username(),
                author=name,  # Use name as author for now
                version="1.0.0",
                tag="cli-created"
            )
            
            # Save recipe to temporary file and create logic
            import tempfile
            with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
                if code_option == "Enter code directly":
                    # Write code to temp file for recipe processing
                    temp_code_file = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False)
                    temp_code_file.write(function_string)
                    temp_code_file.close()
                    recipe.path = temp_code_file.name
                
                recipe_path = save_recipe_to_yaml(recipe, f"temp_logic_{name}", self.get_username())
            
            # Create logic from recipe
            logic = create_logic_from_recipe(recipe_path)
            
            # Update metadata
            logic.about.name = name
            logic.about.description = description if description else None
            logic.language = language
            logic.level = level
            
            # Save logic
            logic.save()
            
            console.print(f"[green]✓[/green] Logic created successfully!")
            console.print(f"Logic ID: {logic.logic_id}")
            
            # Clean up temp files
            try:
                Path(recipe_path).unlink()
                if code_option == "Enter code directly":
                    Path(temp_code_file.name).unlink()
            except:
                pass
            
        except Exception as e:
            console.print(f"[red]✗[/red] Error creating logic: {e}")

    def view_logics(self):
        """View and manage existing logics"""
        try:
            username = self.get_username()
            
            # Get all logics
            logics = NeuProcessLogic.get_all_logics(username)
            
            if not logics:
                console.print("[yellow]No logics found.[/yellow]")
                return
                
            # Create table
            table = Table(title="Available Logics")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")  
            table.add_column("Language", style="yellow")
            table.add_column("Level", style="blue")
            table.add_column("Description", style="white")
            
            logic_choices = []
            for logic in logics:
                table.add_row(
                    logic.logic_id,
                    logic.about.name or "Unnamed",
                    logic.language,
                    logic.level,
                    (logic.about.description or "")[:50] + "..." if logic.about.description and len(logic.about.description) > 50 else (logic.about.description or "")
                )
                logic_choices.append(f"{logic.logic_id} - {logic.about.name or 'Unnamed'}")
            
            console.print(table)
            
            # Let user select a logic for detailed view
            if Confirm.ask("View details for a specific logic?"):
                if logic_choices:
                    selected = self.interactive_select(
                        logic_choices,
                        "Select logic to view details"
                    )
                    if selected:
                        logic_id = selected.split(" - ")[0]
                        self.show_logic_details(logic_id, username)
                    
        except Exception as e:
            console.print(f"[red]✗[/red] Error viewing logics: {e}")

    def show_logic_details(self, logic_id: str, username: str):
        """Show detailed view of a logic with management options"""
        try:
            logic = NeuProcessLogic.from_logic_id(logic_id, username)
            
            # Display logic details
            console.rule(f"[bold]Logic Details: {logic.about.name}")
            
            details_table = Table(show_header=False, box=None)
            details_table.add_row("ID:", logic.logic_id)
            details_table.add_row("Name:", logic.about.name or "Unnamed")
            details_table.add_row("Language:", logic.language)
            details_table.add_row("Level:", logic.level)
            details_table.add_row("Description:", logic.about.description or "No description")
            details_table.add_row("Created:", logic.about.created_at.strftime("%Y-%m-%d %H:%M:%S") if logic.about.created_at else "Unknown")
            
            console.print(details_table)
            console.print()
            
            # Show function preview (first 10 lines)
            if logic.function_string:
                console.print("[bold]Function Preview:[/bold]")
                lines = logic.function_string.split('\n')[:10]
                preview = '\n'.join(lines)
                if len(logic.function_string.split('\n')) > 10:
                    preview += "\n..."
                console.print(Panel(preview, title="Code", border_style="blue"))
            
            # Management options
            action = self.interactive_select(
                ["View full code", "Edit logic", "Delete logic", "Back"],
                "Choose action"
            )
            
            if action == "View full code":
                console.print(Panel(logic.function_string, title="Full Code", border_style="green"))
            elif action == "Edit logic":
                self.edit_logic(logic)
            elif action == "Delete logic":
                self.delete_logic(logic)
                
        except Exception as e:
            console.print(f"[red]✗[/red] Error showing logic details: {e}")

    def edit_logic(self, logic: NeuProcessLogic):
        """Edit an existing logic"""
        console.print("[yellow]Editing logic (press Enter to keep current value):[/yellow]")
        
        # Edit basic info
        name = Prompt.ask("Name", default=logic.about.name or "")
        description = Prompt.ask("Description", default=logic.about.description or "")
        
        # Edit language
        language = self.interactive_select(
            ["python", "bash", "other"],
            "Select language",
            allow_cancel=False
        ) or logic.language
        
        # Edit level
        level = self.interactive_select(
            ["file", "bulk"],
            "Select processing level",
            allow_cancel=False
        ) or logic.level
        
        # Edit function if desired
        if Confirm.ask("Edit function code?"):
            console.print("Enter new function code (press Enter twice to finish):")
            lines = []
            while True:
                line = input()
                if line.strip() == "" and len(lines) > 0 and lines[-1].strip() == "":
                    break
                lines.append(line)
            function_string = '\n'.join(lines[:-1])
        else:
            function_string = logic.function_string
            
        # Update logic
        logic.about.name = name
        logic.about.description = description
        logic.language = language
        logic.level = level
        logic.function_string = function_string
        
        # Save changes
        logic.save()
        console.print("[green]✓[/green] Logic updated successfully!")

    def delete_logic(self, logic: NeuProcessLogic):
        """Delete a logic with confirmation"""
        if Confirm.ask(
            f"Are you sure you want to delete logic '{logic.about.name}' ({logic.logic_id})?",
            default=False
        ):
            logic.delete()
            console.print("[green]✓[/green] Logic deleted successfully!")

    def process_menu(self):
        """Process management menu"""
        while True:
            choice = self.interactive_select(
                ["Create new Process", "View existing Processes", "Back to main menu"],
                "Process operations"
            )
            
            if choice == "Create new Process":
                self.create_process()
            elif choice == "View existing Processes":
                self.view_processes()
            else:
                break

    def create_process(self):
        """Interactive process creation using recipe pattern"""
        console.rule("[bold green]Create New Process")
        
        try:
            # Choose creation method
            method = self.interactive_select(
                ["From existing Logic", "From scripts (manual)"],
                "How would you like to create the process?"
            )
            
            if not method:
                return
            elif method == "From existing Logic":
                self.create_process_from_logic()
            elif method == "From scripts (manual)":
                self.create_process_from_scripts()
                
        except Exception as e:
            console.print(f"[red]✗[/red] Error creating process: {e}")

    def create_process_from_logic(self):
        """Create process from existing logic using recipe pattern"""
        username = self.get_username()
        
        # Get available logics
        logics = NeuProcessLogic.get_all_logics(username)
        if not logics:
            console.print("[yellow]No logics available. Create a logic first.[/yellow]")
            return
            
        # Let user select logic
        logic_choices = [f"{logic.logic_id} - {logic.about.name or 'Unnamed'}" for logic in logics]
        choice = self.interactive_select(logic_choices, "Select logic")
        if not choice:
            return
            
        logic_id = choice.split(" - ")[0]
        logic = NeuProcessLogic.from_logic_id(logic_id, username)
        
        # Get process directory configuration
        console.print("\n[bold]Process Configuration:[/bold]")
        
        # Basic info
        name = Prompt.ask("Process name", default=logic.about.name)
        description = Prompt.ask("Process description", default=logic.about.description or "")
        
        # Container config
        base_image = Prompt.ask("Base container image", default="ubuntu:20.04")
        
        try:
            # Create recipe
            recipe = ProcessDirRecipe(
                logic=ProcessDirRecipe.LogicDetails(
                    name=logic.about.name,
                    username=username
                ),
                config=None  # Use default config for now
            )
            
            # Save recipe to temp file and create process dir
            import tempfile
            recipe_path = save_recipe_to_yaml(recipe, f"temp_process_{name}", username)
            
            # Create process directory from recipe
            process_dir = create_process_dir_from_recipe(recipe_path)
            
            # Create process
            process = NeuProcess.from_process_dir(process_dir)
            
            console.print(f"[green]✓[/green] Process created successfully!")
            console.print(f"Process ID: {process.process_id}")
            
            # Clean up temp file
            try:
                Path(recipe_path).unlink()
            except:
                pass
                
        except Exception as e:
            console.print(f"[red]✗[/red] Error creating process: {e}")

    def create_process_from_scripts(self):
        """Create process from manual scripts"""
        console.print("[yellow]Manual process creation not yet implemented.[/yellow]")
        console.print("This would involve providing install_requirements.sh and main scripts.")

    def view_processes(self):
        """View and manage existing processes"""
        try:
            username = self.get_username()
            
            # Get all processes
            processes = NeuProcess.get_all_processes(username)
            
            if not processes:
                console.print("[yellow]No processes found.[/yellow]")
                return
                
            # Create table
            table = Table(title="Available Processes")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("Description", style="white")
            table.add_column("Status", style="yellow")
            
            process_choices = []
            for process in processes:
                status = "Built" if process.is_built else "Not Built"
                table.add_row(
                    process.process_id,
                    process.process_dir.about.name or "Unnamed",
                    (process.process_dir.about.description or "")[:50] + "..." if process.process_dir.about.description and len(process.process_dir.about.description) > 50 else (process.process_dir.about.description or ""),
                    status
                )
                process_choices.append(f"{process.process_id} - {process.process_dir.about.name or 'Unnamed'}")
            
            console.print(table)
            
            # Let user select a process for detailed view
            if Confirm.ask("View details for a specific process?"):
                if process_choices:
                    selected = self.interactive_select(
                        process_choices,
                        "Select process to view details"
                    )
                    if selected:
                        process_id = selected.split(" - ")[0]
                        self.show_process_details(process_id, username)
                    
        except Exception as e:
            console.print(f"[red]✗[/red] Error viewing processes: {e}")

    def show_process_details(self, process_id: str, username: str):
        """Show detailed view of a process with management options"""
        try:
            process = NeuProcess.from_process_id(process_id, username)
            
            # Display process details
            console.rule(f"[bold]Process Details: {process.process_dir.about.name}")
            
            details_table = Table(show_header=False, box=None)
            details_table.add_row("ID:", process.process_id)
            details_table.add_row("Name:", process.process_dir.about.name or "Unnamed")
            details_table.add_row("Description:", process.process_dir.about.description or "No description") 
            details_table.add_row("Directory:", str(process.process_dir.directory_path))
            details_table.add_row("Built:", "Yes" if process.is_built else "No")
            details_table.add_row("Image Path:", str(process.image_path) if process.is_built else "N/A")
            
            console.print(details_table)
            console.print()
            
            # Management options
            actions = [
                "View directory structure",
                "Build container image" if not process.is_built else "Rebuild container image",
                "Create execution instance",
                "Delete process",
                "Back"
            ]
            
            action = self.interactive_select(actions, "Choose action")
            
            if action == "View directory structure":
                self.show_process_directory_tree(process)
            elif action in ["Build container image", "Rebuild container image"]:
                self.build_process_image(process)
            elif action == "Create execution instance":
                self.create_process_execution(process)
            elif action == "Delete process":
                self.delete_process(process)
                
        except Exception as e:
            console.print(f"[red]✗[/red] Error showing process details: {e}")

    def show_process_directory_tree(self, process: NeuProcess):
        """Show the directory structure of a process"""
        tree = Tree(f"[bold]{process.process_dir.directory_path.name}[/bold]")
        
        def add_directory_to_tree(path: Path, tree_node):
            try:
                for item in sorted(path.iterdir()):
                    if item.is_dir():
                        dir_node = tree_node.add(f"[blue]{item.name}/[/blue]")
                        add_directory_to_tree(item, dir_node)
                    else:
                        tree_node.add(f"[white]{item.name}[/white]")
            except PermissionError:
                tree_node.add("[red]Permission denied[/red]")
        
        add_directory_to_tree(process.process_dir.directory_path, tree)
        console.print(tree)

    def build_process_image(self, process: NeuProcess):
        """Build container image for process"""
        console.print("[yellow]Building container image...[/yellow]")
        
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}")
            ) as progress:
                task = progress.add_task("Building image...", total=None)
                
                # Build the image
                result = process.build_image()
                
                progress.update(task, description="Build complete!")
                
            console.print(f"[green]✓[/green] Image built successfully!")
            console.print(f"Image path: {process.image_path}")
            
        except Exception as e:
            console.print(f"[red]✗[/red] Error building image: {e}")

    def create_process_execution(self, process: NeuProcess):
        """Create a process execution instance"""
        console.print("[bold]Create Process Execution[/bold]")
        
        try:
            # Get execution configuration
            execution_mode = self.interactive_select(
                [mode.value for mode in ExecutionMode],
                "Select execution mode"
            )
            if not execution_mode:
                return
            
            scheduler = self.interactive_select(
                [sched.value for sched in HPCScheduler],
                "Select HPC Scheduler"
            )
            if not scheduler:
                return
            
            # Create basic execution
            exec_instance = NeuProcessExec(
                process=process,
                username=self.get_username(),
                execution_mode=ExecutionMode(execution_mode),
                scheduler=HPCScheduler(scheduler)
            )
            
            # Save execution
            exec_instance.save()
            
            console.print(f"[green]✓[/green] Process execution created!")
            console.print(f"Execution ID: {exec_instance.exec_id}")
            
        except Exception as e:
            console.print(f"[red]✗[/red] Error creating execution: {e}")

    def delete_process(self, process: NeuProcess):
        """Delete a process with confirmation"""
        if Confirm.ask(
            f"Are you sure you want to delete process '{process.process_dir.about.name}' ({process.process_id})?",
            default=False
        ):
            process.delete()
            console.print("[green]✓[/green] Process deleted successfully!")

    def pipeline_menu(self):
        """Pipeline management menu"""
        while True:
            choice = self.interactive_select(
                ["Create new Pipeline", "View existing Pipelines", "Monitor Pipeline Status", "Back to main menu"],
                "Pipeline operations"
            )
            
            if choice == "Create new Pipeline":
                self.create_pipeline()
            elif choice == "View existing Pipelines":
                self.view_pipelines()
            elif choice == "Monitor Pipeline Status":
                self.monitor_pipelines()
            else:
                break

    def create_pipeline(self):
        """Interactive pipeline creation using recipe pattern"""
        console.rule("[bold green]Create New Pipeline")
        
        try:
            username = self.get_username()
            
            # Get basic pipeline info
            name = Prompt.ask("Pipeline name")
            description = Prompt.ask("Pipeline description", default="")
            bids_root = Prompt.ask("BIDS dataset root path")
            author = Prompt.ask("Pipeline author", default=username)
            
            # Validate BIDS root
            if not Path(bids_root).exists():
                console.print(f"[red]✗[/red] BIDS root path does not exist: {bids_root}")
                return
                
            # Get scheduler
            scheduler = self.interactive_select(
                [sched.value for sched in HPCScheduler],
                "Select HPC Scheduler"
            )
            if not scheduler:
                return
            
            # Get execution mode
            execution_mode = self.interactive_select(
                [mode.value for mode in ExecutionMode],
                "Select execution mode"
            )
            if not execution_mode:
                return
            
            # Get available processes
            processes = NeuProcess.get_all_processes(username)
            if not processes:
                console.print("[yellow]No processes available. Create processes first.[/yellow]")
                return
            
            # Create pipeline steps
            steps = []
            step_num = 1
            
            while True:
                console.print(f"\n[bold]Step {step_num}:[/bold]")
                
                step_name = Prompt.ask(f"Step {step_num} name")
                step_desc = Prompt.ask(f"Step {step_num} description (optional)", default="")
                
                # Select processes for this step
                process_choices = [f"{p.process_id} - {p.process_dir.about.name or 'Unnamed'}" for p in processes]
                console.print(f"\n[bold]Select processes for step '{step_name}':[/bold]")
                console.print("Enter process numbers separated by commas (e.g., 1,3,5) or 'done' to finish:")
                
                for i, choice in enumerate(process_choices):
                    console.print(f"{i+1}. {choice}")
                
                selection_input = Prompt.ask("Process selection")
                
                if selection_input.lower() == 'done' or not selection_input.strip():
                    console.print("[yellow]No processes selected for step. Skipping.[/yellow]")
                    continue
                
                try:
                    selected_indices = [int(x.strip()) - 1 for x in selection_input.split(',')]
                    selected_processes = [processes[i] for i in selected_indices if 0 <= i < len(processes)]
                except (ValueError, IndexError):
                    console.print("[red]Invalid selection. Please enter valid numbers.[/red]")
                    continue
                
                if not selected_processes:
                    console.print("[yellow]No valid processes selected for step. Skipping.[/yellow]")
                    continue
                
                # Create process exec recipes for selected processes
                process_exec_recipes = []
                for process in selected_processes:
                    exec_recipe = ProcessExecInStepRecipe(
                        process_id=process.process_id,
                        input_bids_filters={},  # Default empty
                        extra_bind_paths={},    # Default empty
                        extra_environment_variables={}  # Default empty
                    )
                    process_exec_recipes.append(exec_recipe)
                
                # Create step recipe
                step_recipe = PipelineStepRecipe(
                    name=step_name,
                    description=step_desc if step_desc else None,
                    processes=process_exec_recipes
                )
                steps.append(step_recipe)
                
                # Ask if user wants to add another step
                if not Confirm.ask("Add another step?", default=False):
                    break
                    
                step_num += 1
            
            if not steps:
                console.print("[yellow]No steps created. Pipeline creation cancelled.[/yellow]")
                return
            
            # Get cost estimation
            cost = IntPrompt.ask(
                "Estimated compute cost scale (1-10, higher = more intensive)",
                default=5
            )
            
            # Create pipeline recipe
            pipeline_recipe = PipelineRecipe(
                username=username,
                author=author,
                data=bids_root,
                name=name,
                description=description if description else None,
                auto_link=Confirm.ask("Enable auto-linking between steps?", default=False),
                cost=cost,
                steps=steps
            )
            
            # Save recipe to temp file and create pipeline
            import tempfile
            recipe_path = save_recipe_to_yaml(pipeline_recipe, f"temp_pipeline_{name}", username)
            
            # Create pipeline from recipe
            pipeline = construct_pipeline_from_recipe(recipe_path)
            
            # Save pipeline
            pipeline.save()
            
            console.print(f"[green]✓[/green] Pipeline created successfully!")
            console.print(f"Pipeline ID: {pipeline.pipeline_id}")
            
            # Clean up temp file
            try:
                Path(recipe_path).unlink()
            except:
                pass
            
        except Exception as e:
            console.print(f"[red]✗[/red] Error creating pipeline: {e}")

    def view_pipelines(self):
        """View and manage existing pipelines"""
        try:
            username = self.get_username()
            
            # Get all pipelines
            pipelines = NeuPipeline.get_all_pipelines(username)
            
            if not pipelines:
                console.print("[yellow]No pipelines found.[/yellow]")
                return
                
            # Create table
            table = Table(title="Available Pipelines")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("Steps", style="yellow")
            table.add_column("Processes", style="blue")
            table.add_column("Description", style="white")
            
            pipeline_choices = []
            for pipeline in pipelines:
                total_processes = len(pipeline.process_execs)
                table.add_row(
                    pipeline.pipeline_id,
                    pipeline.about.name or "Unnamed",
                    str(len(pipeline.steps)),
                    str(total_processes),
                    (pipeline.about.description or "")[:40] + "..." if pipeline.about.description and len(pipeline.about.description) > 40 else (pipeline.about.description or "")
                )
                pipeline_choices.append(f"{pipeline.pipeline_id} - {pipeline.about.name or 'Unnamed'}")
            
            console.print(table)
            
            # Let user select a pipeline for detailed view
            if Confirm.ask("View details for a specific pipeline?", default=False):
                choice = self.interactive_select(
                    pipeline_choices + ["Cancel"],
                    "Select pipeline"
                )
                
                if choice != "Cancel":
                    pipeline_id = choice.split(" - ")[0]
                    self.show_pipeline_details(pipeline_id, username)
                    
        except Exception as e:
            console.print(f"[red]✗[/red] Error viewing pipelines: {e}")

    def show_pipeline_details(self, pipeline_id: str, username: str):
        """Show detailed view of a pipeline with management options"""
        try:
            pipeline = NeuPipeline.from_pipeline_id(pipeline_id, username)
            
            # Display pipeline details
            console.rule(f"[bold]Pipeline Details: {pipeline.about.name}")
            
            details_table = Table(show_header=False, box=None)
            details_table.add_row("ID:", pipeline.pipeline_id)
            details_table.add_row("Name:", pipeline.about.name or "Unnamed")
            details_table.add_row("Description:", pipeline.about.description or "No description")
            details_table.add_row("BIDS Root:", str(pipeline.bids_root))
            details_table.add_row("Scheduler:", pipeline.scheduler.value)
            details_table.add_row("Steps:", str(len(pipeline.steps)))
            details_table.add_row("Total Processes:", str(len(pipeline.process_execs)))
            details_table.add_row("Ready for Execution:", "Yes" if pipeline.is_ready else "No")
            
            console.print(details_table)
            console.print()
            
            # Show steps in collapsible format
            console.print("[bold]Pipeline Steps:[/bold]")
            for i, step in enumerate(pipeline.steps):
                step_panel = self.create_step_panel(step, i + 1)
                console.print(step_panel)
            
            # Management options
            actions = [
                "Execute pipeline",
                "View logs",
                "Monitor status", 
                "Kill all jobs",
                "Delete pipeline",
                "Back"
            ]
            
            action = self.interactive_select(actions, "Choose action")
            
            if action == "Execute pipeline":
                self.execute_pipeline(pipeline)
            elif action == "View logs":
                self.view_pipeline_logs(pipeline)
            elif action == "Monitor status":
                self.monitor_single_pipeline(pipeline)
            elif action == "Kill all jobs":
                self.kill_pipeline_jobs(pipeline)
            elif action == "Delete pipeline":
                self.delete_pipeline(pipeline)
                
        except Exception as e:
            console.print(f"[red]✗[/red] Error showing pipeline details: {e}")

    def create_step_panel(self, step: NeuPipelineStep, step_number: int) -> Panel:
        """Create a panel showing step details"""
        step_content = f"[bold]Description:[/bold] {step.description or 'No description'}\n"
        step_content += f"[bold]Processes ({len(step.process_execs)}):[/bold]\n"
        
        for i, proc_exec in enumerate(step.process_execs):
            process_name = proc_exec.process.process_dir.about.name or "Unnamed"
            step_content += f"  {i+1}. {proc_exec.process.process_id} - {process_name}\n"
            step_content += f"     Exec ID: {proc_exec.exec_id}\n"
            step_content += f"     Mode: {proc_exec.execution_mode.value}\n"
        
        return Panel(
            step_content.strip(),
            title=f"Step {step_number}: {step.name}",
            border_style="blue"
        )

    def execute_pipeline(self, pipeline: NeuPipeline):
        """Execute a pipeline"""
        if not pipeline.is_ready:
            console.print("[red]Pipeline is not ready for execution. Check configuration.[/red]")
            return
            
        console.print("[yellow]Executing pipeline...[/yellow]")
        
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}")
            ) as progress:
                task = progress.add_task("Starting execution...", total=None)
                
                # Execute the pipeline
                result = pipeline.execute_via_python()
                
                progress.update(task, description="Execution started!")
                
            console.print(f"[green]✓[/green] Pipeline execution started!")
            console.print(f"Result: {result}")
            
        except Exception as e:
            console.print(f"[red]✗[/red] Error executing pipeline: {e}")

    def view_pipeline_logs(self, pipeline: NeuPipeline):
        """View pipeline logs"""
        try:
            log_file = pipeline.log_file_path
            
            if not log_file.exists():
                console.print("[yellow]No log file found.[/yellow]")
                return
                
            with open(log_file, 'r') as f:
                logs = f.read()
                
            if not logs.strip():
                console.print("[yellow]Log file is empty.[/yellow]")
                return
                
            console.print(Panel(logs, title="Pipeline Logs", border_style="green"))
            
        except Exception as e:
            console.print(f"[red]✗[/red] Error viewing logs: {e}")

    def monitor_single_pipeline(self, pipeline: NeuPipeline):
        """Monitor status of a single pipeline"""
        console.print(f"[bold]Monitoring Pipeline: {pipeline.about.name}[/bold]")
        
        try:
            # Get current jobs
            jobs = pipeline.get_all_jobs()
            
            if not jobs:
                console.print("[yellow]No running jobs found.[/yellow]")
                return
                
            table = Table(title="Running Jobs")
            table.add_column("Job ID", style="cyan")
            table.add_column("Process", style="green")
            table.add_column("Status", style="yellow")
            table.add_column("Queue", style="blue")
            
            for job in jobs:
                table.add_row(
                    job.get("job_id", "Unknown"),
                    job.get("process_name", "Unknown"),
                    job.get("status", "Unknown"),
                    job.get("queue", "Unknown")
                )
                
            console.print(table)
            
        except Exception as e:
            console.print(f"[red]✗[/red] Error monitoring pipeline: {e}")

    def kill_pipeline_jobs(self, pipeline: NeuPipeline):
        """Kill all jobs in a pipeline"""
        if Confirm.ask(
            "Are you sure you want to kill all jobs in this pipeline?",
            default=False
        ):
            try:
                result = pipeline.kill_all_jobs()
                console.print(f"[green]✓[/green] Kill command sent for all jobs!")
                console.print(f"Result: {result}")
            except Exception as e:
                console.print(f"[red]✗[/red] Error killing jobs: {e}")

    def delete_pipeline(self, pipeline: NeuPipeline):
        """Delete a pipeline with confirmation"""
        if Confirm.ask(
            f"Are you sure you want to delete pipeline '{pipeline.about.name}' ({pipeline.pipeline_id})?",
            default=False
        ):
            pipeline.delete()
            console.print("[green]✓[/green] Pipeline deleted successfully!")

    def monitor_pipelines(self):
        """Monitor all pipelines"""
        console.rule("[bold blue]Pipeline Status Monitor")
        
        try:
            username = self.get_username()
            pipelines = NeuPipeline.get_all_pipelines(username)
            
            if not pipelines:
                console.print("[yellow]No pipelines found.[/yellow]")
                return
                
            # Create status table
            table = Table(title="Pipeline Status Overview")
            table.add_column("Pipeline", style="green")
            table.add_column("ID", style="cyan")
            table.add_column("Steps", style="yellow")
            table.add_column("Running Jobs", style="blue")
            table.add_column("Ready", style="white")
            
            for pipeline in pipelines:
                try:
                    jobs = pipeline.get_all_jobs()
                    running_jobs = len(jobs) if jobs else 0
                    ready_status = "Yes" if pipeline.is_ready else "No"
                    
                    table.add_row(
                        pipeline.about.name or "Unnamed",
                        pipeline.pipeline_id,
                        str(len(pipeline.steps)),
                        str(running_jobs),
                        ready_status
                    )
                except Exception as e:
                    table.add_row(
                        pipeline.about.name or "Unnamed",
                        pipeline.pipeline_id,
                        str(len(pipeline.steps)),
                        "Error",
                        "Error"
                    )
                    
            console.print(table)
            
        except Exception as e:
            console.print(f"[red]✗[/red] Error monitoring pipelines: {e}")


def main():
    """Main CLI entry point"""
    console.print(
        Panel(
            "Press [bold]Ctrl+C[/bold] to cancel at any time",
            title="NeuroAnalyst CLI",
        )
    )
    
    cli = NeuroAnalystCLI()
    
    try:
        cli.main_menu()
    except KeyboardInterrupt:
        console.print("\n[red]Operation cancelled by user.[/red]")
        raise typer.Exit(code=130)
    except EOFError:
        console.print("\n[red]No input provided. Exiting.[/red]")
        raise typer.Exit(code=130)
    except Exception as e:
        console.print(f"\n[red]Unexpected error: {e}[/red]")
        raise typer.Exit(code=1)


@app.command()
def start():
    """Start the NeuroAnalyst CLI application"""
    main()


if __name__ == "__main__":
    typer.run(main)